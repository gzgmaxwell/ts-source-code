// 1. 更容易帮助我们发现程序里的问题
// 2. 语法提示更加完善，有了类型之后，写代码非常爽
// 3. 语义更强，代码可读性更高

type Point = { x: number, y: number };

function getDistance(point1: Point, point2: Point) {
    return [point2.x - point1.x, point2.y - point1.y];
}

getDistance({ x: 2, y: 1}, { x: 2, y:2 });