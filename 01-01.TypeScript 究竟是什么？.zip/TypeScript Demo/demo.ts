function compare(x) {
    if(1 < x && x < 3) {
        console.log('hello')
    }
}

const object = {
    firstName: 'Dell',
    lastName: 'Lee'
}

console.log(object.firstName + object.lastName);
