if("" == 0) {
    console.log('hello');
}

function compare(x) {
    if(1 < x < 3) {
        console.log('hello')
    }
}

const object = {
    firstName: 'Dell',
    lastName: 'Lee'
}

console.log(object.firtsName + object.latsName + c);
